<?php

namespace App\DataFixtures;

use App\Entity\Decouverte;
use Faker\Factory as Faker;
use App\DataFixtures\ContinentFixtures;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;

class DecouverteFixtures extends Fixture implements DependentFixtureInterface
{
    public function load(ObjectManager $manager)
    {
    	$faker = Faker::create();

    	// création de plusieurs produits
	    for($i = 0; $i < 10; $i++) {
	    	// instanciation d'une entité
		    $decouverte = new Decouverte();
		    $decouverte->setTitle( $faker->sentence(10) );
		    $decouverte->setText( $faker->text(200) );
		    //$decouverte->setImage( $faker->image('public/img/decouverte', 800, 450, null, false) );
		    $decouverte->setImage( 'default.jpg' );

		    // récupération des références des catégories
		    $randomContinent = random_int(0, 4);
		    $continent = $this->getReference("continent$randomContinent");

		    // associer une catégorie au produit
		    $decouverte->addIdcontinent($continent);

		    // doctrine : méthode persist permet de créer un enregistrement (INSERT INTO)
		    $manager->persist($decouverte);
	    }

	    // doctrine : méthode flush permet d'exécuter les requêtes SQL (à exécuter une seule fois)
        $manager->flush();
	}
	
	public function getDependencies()
	{
		return [
			ContinentFixtures::class
		];
	}
}
