<?php

namespace App\Controller;

use App\Entity\Decouverte;
use App\Form\DecouverteType;
use App\Repository\DecouverteRepository;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class DecouverteController extends AbstractController
{
    /**
     * @Route("/decouverte", name="decouverte.index")
     */
    public function index(DecouverteRepository $decouverteRepository)
    {
        $results = $decouverteRepository->findAll();
        //dd($results);
        return $this->render('decouverte/index.html.twig', [
            'results' => $results
        ]);
    }

    /**
     * @Route("/decouverte/form", name="decouverte.form")
     */

    public function form(Request $request, EntityManagerInterface $entityManager, int $id = null, DecouverteRepository $decouverteRepository): Response
    {
        //affichage d'un formulaire
        $type = DecouverteType::class;
        $model = $id ? $decouverteRepository->find($id) : new Decouverte();

        $form = $this->createForm($type, $model);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            //dd($model);

            $entityManager->persist($model);
            $id ? null : $entityManager->persist($model);
            $entityManager->flush();
            //message de confirmation
            $message = $id ? "le produit a été modifié " : "lE PRODUit a été ajouté";
            $this->addFlash('notice', $message);
            //redirection
            $this->redirectToRoute('decouverte.index');
        }
        return $this->render('decouverte/form.html.twig', [
            'form' => $form->createView()
        ]);
    }
    /**
	 * @Route("/decouverte/{id}", name="decouverte.details")
    */
	public function details(int $id, DecouverteRepository $decouverteRepository):Response
	{
		$decouverte = $decouverteRepository->find($id);
		return $this->render('decouverte/details.html.twig', [
			'decouverte' => $decouverte
		]);
    }
}
