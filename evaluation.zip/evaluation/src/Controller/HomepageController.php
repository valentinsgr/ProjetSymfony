<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use App\Repository\DecouverteRepository;
use App\Repository\ContinentRepository;

class HomepageController extends AbstractController
{
    /**
     * @Route("/", name="homepage.index")
     */
    public function index(DecouverteRepository $decouverteRepository)
    {
        $results = $decouverteRepository->findAll();
        //dd($results);
        return $this->render('homepage/index.html.twig', [
            'results' => $results
        ]);
    }
}
