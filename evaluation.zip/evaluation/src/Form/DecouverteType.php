<?php

namespace App\Form;

use App\Entity\Decouverte;
use App\Entity\Continent;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Image;
use Symfony\Component\Validator\Constraints\NotBlank;

class DecouverteType extends AbstractType
{


    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Decouverte::class,
        ]);
    }


    public function buildForm(FormBuilderInterface $builder, array $options)
    {

        $builder
            ->add('title', TextType::class, [
                'constraints' => [
                    new NotBlank(['message' => "le Nom est obligatoire"])
                ]
            ])
            ->add('text', TextareaType::class, [
                'constraints' => [
                    new NotBlank(['message' => "la description est obligatoire"])
                ]
            ])
            ->add('image', FileType::class, [
                'data_class' => null, //indique qu'aucune classe ne va contenir les propriétés d'une image transférée.
                'constraints' => $builder->getData()->getId() ? [] : [
                    new NotBlank(['message' => "L'image est obligatoire"]),
                    new Image(['mimeTypes' => ['image/jpeg', 'image/png', 'image/gif', 'image/svg+xml'],
                        'mimeTypesMessage' => "l'image n est pas dans un format web"])
                ]
            ])

            ->add('continent', EntityType::class, [
                'class' => Continent::class,
                'choice_label' => 'name',
                'placeholder' => '',
                'constraints' => [new NotBlank([
                    'message' => 'Le continent est obligatoire'
                ])
                ]
            ]);
        //$builder->addEventSubscriber(new ArticleFormSubscriber());
    }




}